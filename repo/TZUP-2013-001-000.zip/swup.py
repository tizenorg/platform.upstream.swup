#!/usr/bin/python

import ConfigParser
from optparse import OptionParser
import urllib2
from lxml import etree
from BeautifulSoup import *

update_repo="file:///home/nashif/system-updates/repo"
update_cache="/var/cache/updates"

class FakeSecHead(object):
    def __init__(self, fp):
        self.fp = fp
        self.sechead = '[os-release]\n'
    def readline(self):
        if self.sechead:
            try: return self.sechead
            finally: self.sechead = None
        else: return self.fp.readline()

def get_current_version():
    config = ConfigParser.SafeConfigParser()
    config.readfp(FakeSecHead(open('/etc/os-release')))
    return dict(config.items('os-release'))

def list_updates():
    print "Getting list of available updates..."
    response = urllib2.urlopen("%s/data/updatemd.xml" % update_repo )
    updatemd = response.read()
    root = etree.XML(updatemd)
    d = root.xpath("//data")
    for i in d:
        typ = i.attrib['type']
        if typ == 'update':
            loc = i.xpath("location")[0]
            href = loc.attrib['href']
            up = urllib2.urlopen("%s/%s" % (update_repo, href) )
            update = up.read()
            up_root = etree.XML(update)
            ups = up_root.xpath("//update")
            for u in ups:
                updata = u.attrib
                print "  %s:" %updata['id']
                print "       %s" %u.xpath("title")[0].text

parser = OptionParser()
parser.add_option("-V", "--os-version", action="store_true", dest="osver", default=False,
                  help="Current OS Version")
parser.add_option("-l", "--list-updates", action="store_true", dest="listupdates", default=False,
                  help="List updates")
parser.add_option("-d", "--download-only", action="store_true", dest="downloadonly", default=False,
                  help="Download only")
parser.add_option("-i", "--install",  dest="install", metavar="LABEL",
                  help="Install update")
parser.add_option("-r", "--recommended",  dest="recommended", action="store_true", default=False,
                  help="Install recommended updates only")
parser.add_option("-q", "--quiet",
                  action="store_false", dest="verbose", default=True,
                  help="don't print status messages to stdout")

(options, args) = parser.parse_args()

if options.osver:
    os_release = get_current_version()
    print os_release['version_id'].strip('"')

if options.listupdates:
    list_updates()
