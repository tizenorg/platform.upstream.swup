#!/bin/sh

for s in `find scripts/pre -name *.sh`; do 
    echo "Applying pre script: $s"
    sh $s
done


# install packages
rpm -Uvh packages/*.rpm

for s in `find scripts/post -name *.sh`; do 
    echo "Applying post script: $s"
    sh $s
done
