#!/bin/sh

# create packages from delta
for drpm in delta/*.drpm; do 
    target=$(rpm -qp --queryformat 'packages/%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}.rpm\n' $drpm)
    echo "Create package $target from delta: $drpm"
    /usr/bin/applydeltarpm $drpm $target 
done
